
i = input("Enter text to test a palindrome:")

print(i[::-1])
    
i = "78Q9"
print(i.isdigit(), "is digit")
print(i.isalnum(), "is alphanum")
print("done")

