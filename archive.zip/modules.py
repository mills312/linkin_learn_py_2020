import math

print("The rsq root of 16 is", math.sqrt(16))
print("Pi is", math.pi)
